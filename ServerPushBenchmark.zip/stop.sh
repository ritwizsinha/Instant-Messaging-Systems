#!/bin/bash

killall node