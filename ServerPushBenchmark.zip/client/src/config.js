export const POLLING_SERVER = 'http://localhost:3001/message';
export const WEBSOCKET_SERVER = 'http://localhost:3002';
export const SSE_SERVER = 'http://localhost:3003/stream';
export const LONG_POLLING_SERVER = 'http://localhost:3004/pool';