"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.messageArr = void 0;
exports.messageArr = __spreadArray([], Array(1000)).map(function () {
    return __spreadArray([], Array(~~(Math.random() * 100 + 3))).map(function () {
        return String.fromCharCode(Math.random() * (123 - 97) + 97);
    }).join('');
});
//# sourceMappingURL=data.js.map