"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var socket_io_client_1 = require("socket.io-client");
var data_1 = require("../data");
var config_1 = require("../config");
var run = 0, index = 0;
var length = data_1.messageArr.length;
var id = setInterval(function () {
    run++;
    if (run === 100) {
        clearInterval(id);
    }
    else {
        var socket_1 = socket_io_client_1.io(config_1.WEBSOCKET_SERVER);
        socket_1.on('connect', function () {
            socket_1.emit('message', {
                message: data_1.messageArr[index],
                time: Date.now(),
            });
            socket_1.disconnect();
        });
        index = (index + 1) % length;
    }
}, 1000);
//# sourceMappingURL=websocket-mock.js.map