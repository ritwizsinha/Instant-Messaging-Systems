"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var express_1 = __importDefault(require("express"));
var cors_1 = __importDefault(require("cors"));
var config_1 = require("./config");
var app = express_1.default();
app.use(cors_1.default());
app.use(express_1.default.urlencoded({
    extended: true,
}));
app.use(express_1.default.json());
var pool = [];
app.get('/pool', function (req, res) {
    console.log(pool.length);
    pool.push(res);
});
app.post('/message', function (req, res) {
    var _a = req.body, message = _a.message, time = _a.time;
    pool.forEach(function (res) { return res.json({ message: message, time: time }); });
    res.end();
    pool.length = 0;
});
app.listen(config_1.LONG_POLLING_PORT, function () {
    console.log("Listening to  port " + config_1.LONG_POLLING_PORT);
});
//# sourceMappingURL=longPollingServer.js.map