"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var express_1 = __importDefault(require("express"));
var http_1 = __importDefault(require("http"));
var config_1 = require("./config");
var app = express_1.default();
var server = http_1.default.createServer(app);
var io = require('socket.io')(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});
io.on('connection', function (socket) {
    console.log("New WS Connection....");
    console.log(socket.id);
    socket.on('message', function (data) {
        io.emit('data', data);
    });
});
server.listen(config_1.WEBSOCKET_PORT, function () {
    console.log("Listening on port " + config_1.WEBSOCKET_PORT);
});
//# sourceMappingURL=websocketServer.js.map