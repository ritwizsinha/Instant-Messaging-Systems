"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var express_1 = __importDefault(require("express"));
var cors_1 = __importDefault(require("cors"));
var config_1 = require("./config");
var app = express_1.default();
app.use(express_1.default.urlencoded({
    extended: true,
}));
app.use(cors_1.default());
app.use(express_1.default.json());
app.listen(config_1.SSE_PORT, function () {
    console.log("Listening on " + config_1.SSE_PORT);
});
var posts = [];
var clients = [];
app.get('/stream', function (request, response) {
    console.log("Here");
    ;
    var headers = {
        'Content-Type': 'text/event-stream',
        'Connection': 'keep-alive',
        'Cache-Control': 'no-cache'
    };
    response.writeHead(200, headers);
    var data = "data: " + JSON.stringify(posts) + "\n\n";
    response.write(data);
    var clientId = Date.now();
    var newClient = {
        id: clientId,
        response: response
    };
    clients.push(newClient);
    request.on('close', function () {
        console.log(clientId + " Connection closed");
        clients = clients.filter(function (client) { return client.id !== clientId; });
    });
});
app.post('/message', function (request, response) {
    var _a = request.body, message = _a.message, time = _a.time;
    console.log(message, time);
    posts.push({ message: message, time: time });
    response.json({ message: message, time: time });
    sendToAllClients({ message: message, time: time });
});
function sendToAllClients(_a) {
    var message = _a.message, time = _a.time;
    clients.forEach(function (client) {
        client.response.write("data: " + JSON.stringify({ message: message, time: time }) + "\n\n");
    });
}
//# sourceMappingURL=SSE_Server.js.map