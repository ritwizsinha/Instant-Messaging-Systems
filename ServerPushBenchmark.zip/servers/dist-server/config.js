"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LONG_POLLING_SERVER = exports.LONG_POLLING_PORT = exports.SSE_SERVER = exports.SSE_PORT = exports.WEBSOCKET_PORT = exports.WEBSOCKET_SERVER = exports.POLLING_SERVER = exports.POLLING_PORT = void 0;
var dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
exports.POLLING_PORT = process.env.POLLING_SERVER_PORT;
exports.POLLING_SERVER = 'http://localhost:3001/message';
exports.WEBSOCKET_SERVER = 'http://localhost:3002';
exports.WEBSOCKET_PORT = process.env.WEBSOCKET_PORT;
exports.SSE_PORT = process.env.SSE_PORT;
exports.SSE_SERVER = "http://localhost:3003";
exports.LONG_POLLING_PORT = process.env.LONG_POLLING_PORT;
exports.LONG_POLLING_SERVER = "http://localhost:3004";
//# sourceMappingURL=config.js.map